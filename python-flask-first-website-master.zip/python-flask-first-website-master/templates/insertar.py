import sys
from PyQt5.QtWidgets import QApplication, QDialog, QGridLayout, QMessageBox, QLabel, QPushButton, QLineEdit, QSpinBox
from PyQt5 import uic
from PyQt5.QtSql import QSqlDatabase, QSqlQuery


#Establecer conexión a la base de datos MySql
#class Dialogo(QDialog):
def __init__(self):
  self.db = QSqlDatabase.addDatabase('QMYSQL')
  self.db.setHostName("localhost")
  self.db.setDatabaseName("taller2")
  self.db.setUserName("root")
  self.db.setPassword("")

  self.Enviar.clicked.connect(self.submit)

def Insertar(self):
    estado = self.db.open()
    if estado == False:
        QMessageBox.warning(self, "Error", self.db.lastError().text(), QMessageBox.Discard)
    else:
        nombre = self.nombre.text()
        cedula = self.cedula.text()
        email = self.email.text()
        telefono = self.telefono.text()
        banco = self.banco.text()
        comentarios = self.comentarios.text()

        sql = "INSERT INTO usuarios(nombre, cedula, email, telefono, banco, comentarios) VALUES (:nombre, :cedula, :email, :telefono, :banco, :comentarios)"
        consulta = QSqlQuery()
        consulta.prepare(sql)
        consulta.bindValue(":nombre", nombre)
        consulta.bindValue("cedula", cedula)
        consulta.bindValue(":email", email)
        consulta.bindValue(":telefono", telefono)
        consulta.bindValue(":banco", banco)
        consulta.bindValue(":comentarios", comentarios)
        estado = consulta.exec_()
        if estado == True:
            QMessageBox.information(self, "Correcto", "Datos guardados", QMessageBox.Discard)
        else:
            QMessageBox.warning(self, "Error", self.db.lastError().text(), QMessageBox.Discard)

        self.db.close()

