from flask import Flask, render_template

app = Flask(__name__)

# Crear el menu
@app.route('/test')
def test():
    return "Home Page"

@app.route('/test/about/')
def about_test():
    return "About Page"

@app.route('/test/Programas/')
def Programas_test():
    return "Programas Page"

@app.route('/test/Inscripcion/')
def Inscripcion_test():
    return "Inscripcion Page"

@app.route('/test/Pagos/')
def Pagos_test():
    return "Pagos Page"

@app.route('/test/Contactenos/')
def Contactenos_test():
    return "Contactenos Page"

# enlazar los menu
@app.route('/')
def home():
    return render_template("home.html")

@app.route('/about', strict_slashes=False)
def about():
    return render_template("about.html")

@app.route('/Programas', strict_slashes=False)
def programas():
    return render_template("Programas.html")

@app.route('/Inscripcion', strict_slashes=False)
def inscripcion():
    return render_template("Inscripcion.html")

@app.route('/Pagos', strict_slashes=False)
def pagos():
    return render_template("Pagos.html")

@app.route('/Contactenos', strict_slashes=False)
def contactenos():
    return render_template("Contactenos.html")

# para ejecutar el archivo
if __name__ == '__main__':
    app.run(debug=True)
